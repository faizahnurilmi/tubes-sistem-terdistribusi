package client;

import server.OperationRMI;
import java.rmi.Naming;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class TransactionApp extends JFrame {

    private JTextField tfId, tfName, tfAmount, tfBalance;
    private JComboBox<String> cbTransactionType;
    private OperationRMI service;

    public TransactionApp() {
        try {
            // Hubungkan ke server RMI
            service = (OperationRMI) Naming.lookup("rmi://192.168.1.7:2000/BankService");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Koneksi ke server gagal.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            System.exit(0);
        }

        setTitle("Aplikasi Transaksi Bank");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        setLayout(null);

        JLabel lblId = new JLabel("ID:");
        lblId.setBounds(20, 20, 100, 25);
        add(lblId);

        tfId = new JTextField();
        tfId.setBounds(150, 20, 200, 25);
        add(tfId);

        JLabel lblName = new JLabel("Nama:");
        lblName.setBounds(20, 60, 100, 25);
        add(lblName);

        tfName = new JTextField();
        tfName.setBounds(150, 60, 200, 25);
        add(tfName);

        JLabel lblTransactionType = new JLabel("Jenis Transaksi:");
        lblTransactionType.setBounds(20, 100, 100, 25);
        add(lblTransactionType);

        cbTransactionType = new JComboBox<>(new String[]{"Setor", "Tarik"});
        cbTransactionType.setBounds(150, 100, 200, 25);
        add(cbTransactionType);

        JLabel lblAmount = new JLabel("Jumlah:");
        lblAmount.setBounds(20, 140, 100, 25);
        add(lblAmount);

        tfAmount = new JTextField();
        tfAmount.setBounds(150, 140, 200, 25);
        add(tfAmount);

        JButton btnSubmit = new JButton("Proses");
        btnSubmit.setBounds(150, 180, 100, 30);
        btnSubmit.addActionListener(this::submitTransaction);
        add(btnSubmit);

        JLabel lblBalance = new JLabel("Saldo Akhir:");
        lblBalance.setBounds(20, 220, 100, 25);
        add(lblBalance);

        tfBalance = new JTextField();
        tfBalance.setBounds(150, 220, 200, 25);
        tfBalance.setEditable(false);
        add(tfBalance);
    }

    private void submitTransaction(ActionEvent evt) {
        String id = tfId.getText();
        String name = tfName.getText();
        String type = cbTransactionType.getSelectedItem().toString().toLowerCase();
        double amount;

        try {
            amount = Double.parseDouble(tfAmount.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Jumlah harus berupa angka.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Kirim transaksi ke server
            String result = service.processTransaction(id, name, type, amount);
            double balance = service.getBalance(id);
            tfBalance.setText("Rp" + balance);

            JOptionPane.showMessageDialog(this, result, "Info", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Transaksi gagal.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TransactionApp().setVisible(true));
    }
}
