package server;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Main {
    public static void main(String[] args) {
        try {
            // Buat instance layanan dan daftarkan ke registry
            Services service = new Services();
            Registry registry = LocateRegistry.createRegistry(2000);
            registry.bind("BankService", service);

            System.out.println("Server Bank siap melayani pada port 2000.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
