package server;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface OperationRMI extends Remote {
    public String processTransaction(String id, String name, String type, double amount) throws RemoteException;
    public double getBalance(String id) throws RemoteException;
}
