package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;

public class Services extends UnicastRemoteObject implements OperationRMI {

    private static final long serialVersionUID = 1L;

    // Penyimpanan data saldo pengguna
    private HashMap<String, Double> accountBalances = new HashMap<>();

    protected Services() throws RemoteException {
        super();
    }

    @Override
    public synchronized String processTransaction(String id, String name, String type, double amount) throws RemoteException {
        // Jika akun belum ada, inisialisasi dengan saldo 0
        accountBalances.putIfAbsent(id, 0.0);
        double currentBalance = accountBalances.get(id);

        if (type.equalsIgnoreCase("setor")) {
            currentBalance += amount;
            accountBalances.put(id, currentBalance);
            return "Setoran berhasil. Saldo baru: Rp" + currentBalance;
        } else if (type.equalsIgnoreCase("tarik")) {
            if (amount > currentBalance) {
                return "Gagal: Saldo tidak mencukupi.";
            }
            currentBalance -= amount;
            accountBalances.put(id, currentBalance);
            return "Penarikan berhasil. Saldo baru: Rp" + currentBalance;
        } else {
            return "Transaksi gagal: Jenis transaksi tidak dikenal.";
        }
    }

    @Override
    public synchronized double getBalance(String id) throws RemoteException {
        return accountBalances.getOrDefault(id, 0.0);
    }
}
